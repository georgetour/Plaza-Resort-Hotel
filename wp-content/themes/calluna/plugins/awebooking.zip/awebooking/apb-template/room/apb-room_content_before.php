<?php
/**
 * Before content add data of javascript.
 *
 * @author  AweTeam
 * @package AweBooking/Templates
 * @version 1.0
 */

?>

<div class="apb-content apb-content-js">
