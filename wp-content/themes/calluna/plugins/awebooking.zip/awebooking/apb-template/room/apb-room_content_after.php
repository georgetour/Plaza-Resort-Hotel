<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * After content add data of javascript.
 *
 * @author  AweTeam
 * @package AweBooking/Templates
 * @version 1.0
 */

?>
</div>
